Theme Name: 부트스트랩 테마
Theme URI: https://g6.demo.sir.kr/
Maker: SIRSOFT
Maker URI: https://sir.kr
Version: 1.0.0
Detail: 부트스트랩 테마는 SIR에서 제공하는 그누보드6 테마입니다.
License: MIT
